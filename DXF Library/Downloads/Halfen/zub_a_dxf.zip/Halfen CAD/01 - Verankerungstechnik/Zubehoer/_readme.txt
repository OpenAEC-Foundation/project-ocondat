Gew�hrleistung
Die vorliegenden Bemessungsprogramme und CAD-Bibliotheken sind Produkte der HALFEN GmbH, Langenfeld, Deutschland.
Sie sind urheberrechtlich gesch�tzt, alle Rechte bleiben vorbehalten. Ver�nderungen der Software oder der Bibliotheken
bzw. ihrer Teilkomponenten bed�rfen der vorherigen Zustimmung des Urhebers.
Wir weisen darauf hin, da� nach dem Stand der Technik Fehler in Softwareprogrammen und CAD-Bibliotheken nicht vollst�ndig
ausgeschlossen werden k�nnen. Die HALFEN GmbH �bernimmt daher keine Haftung daf�r, dass die mit der vorliegenden Software
oder den CAD-Bibliotheken durchgef�hrten Bemessungen oder Planungen vollst�ndig fehlerfrei sind. Insbesondere ist der
Anwender gehalten, die Eingabewerte, Bemessungsergebnisse und Grafiken zu kontrollieren und anhand geltender Unterlagen
(Normen und Zulassungen) auf Plausibilit�t hin zu pr�fen.
Der Anwender bleibt f�r die von ihm verwendeten Bemessungsergebnisse allein verantwortlich!


Warranty
This calculation programs and CAD libraries are products of Halfen GmbH, Langenfeld, Germany. The software is copyrighted
and all rights are reserved. Any changes to the programs or sub-components require the prior consent of the author.
While every care has been taken in the preparation of the software, errors in the program and the CAD libraries cannot be
fully excluded. Therefore, Halfen GmbH cannot accept responsibility if the results reached with this software or CAD
libraries contains errors. It is the user�s responsibility to check the input values and drawings and verify their
feasibility based on current standards and approvals.
The user remains solely responsible for the calculation results he applies.